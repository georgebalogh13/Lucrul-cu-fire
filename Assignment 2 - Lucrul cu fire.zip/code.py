import threading
from time import sleep

class Cub:
  def __init__(self,muchie):
    self.muchie = muchie
  
  def volum(self):
      sleep(4)
      print("Calculare volum...")
      print(self.muchie * self.muchie * self.muchie)

  def lungime(self):
      print("Calculare lungime...")
      print(12 * self.muchie)

cub = Cub(4)
t = threading.Thread(target = cub.volum)
t1 = threading.Thread(target = cub.lungime)

t.start()
t.join()

t1.start()
t1.join()

